# Changelog

## 0.3.5

- Fixed a Steam invite race that could leave you outside a friend's lobby after clicking Join Game with the mod running.
- Prevented duplicate join attempts from overlapping.

## 0.3.4

- Added a host-only **Show Items** room setting. Ability icons are hidden by default. Turning the setting on shows them on the roster for everyone using this version.

## 0.3.3

- Added a shared practice island with keyboard and controller support.
- Updated the lobby roster and Steam friend invite menu.
