# Bopl 8 Players

Play Bopl Battle with up to 8 players in a private Steam lobby. The host can set the lobby size from 4 to 8.

## Features

- Invite Steam friends in-game. Hosts can remove players before a match.
- See who’s ready and use the standard loadout and keybind controls. Hosts can turn on **Show Items** to display ability icons on the roster for everyone. Icons are hidden by default.
- Practice movement and jumping on a shared island after you ready up. Supports keyboard and controller.
- Press **F8** to see FPS, peer ping, and connection stats.

## Install

Install **Bopl8Players** in Thunderstore Mod Manager or r2modman and choose **Start modded**. In the game, open **Online Play** → **Invite Players**.

Requires Bopl Battle 2.5.1 on Windows (Steam) and BepInExPack. Everyone needs the same mod version. Public matchmaking and replay recording are disabled. The game’s four teams are available.

This is an alpha. The lobby was tested with simulated peers. Full 5–8 player matches and reconnects still need live testing.

[GitHub and manual install](https://github.com/rpowergso/BoplBattle8Players) · Based on [MoreBoplPlayers](https://github.com/AbstractMelon/MoreBoplPlayers) (BSD 3-Clause).
